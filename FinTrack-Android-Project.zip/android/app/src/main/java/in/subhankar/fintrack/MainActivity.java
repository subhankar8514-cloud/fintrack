package in.subhankar.fintrack;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
